module.exports = {
    semi: false,
    singleQuote: false,
    trailingComma: 'es5',
    bracketSpacing: true,
    jsxBracketSameLine: false,
    arrowParens: 'always',
    printWidth: 80,
    tabWidth: 4,
    plugins: ['prettier-plugin-tailwindcss'],
}
